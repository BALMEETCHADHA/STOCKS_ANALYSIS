"""
forecast.py
-----------
Two things:
1. A short-horizon price forecast using ARIMA (statsmodels) -- falls back
   to a simple linear-regression trend projection if ARIMA fails to
   converge (e.g. too little data).
2. A rule-based BUY / SELL / HOLD call that combines:
     - trend (from analysis.py)
     - RSI / MACD momentum
     - distance to nearest support / resistance (from swing points)
   and produces the "next suggested entry / call zone" the user asked for.

This is a transparent, explainable model (not a black box) so every
number in the report can be traced back to a rule.
"""

import numpy as np
import pandas as pd


def forecast_next_period(df: pd.DataFrame, steps: int = 5) -> dict:
    close = df["Close"]
    try:
        from statsmodels.tsa.arima.model import ARIMA
        model = ARIMA(close, order=(5, 1, 0))
        fit = model.fit()
        forecast = fit.forecast(steps=steps)
        method = "ARIMA(5,1,0)"
        values = [round(float(v), 2) for v in forecast]
    except Exception:
        # fallback: linear regression on the last 30 candles
        window = close.tail(30).values
        x = np.arange(len(window))
        coeffs = np.polyfit(x, window, 1)
        slope, intercept = coeffs[0], coeffs[1]
        future_x = np.arange(len(window), len(window) + steps)
        values = [round(float(slope * fx + intercept), 2) for fx in future_x]
        method = "Linear trend projection"

    return {
        "method": method,
        "horizon_steps": steps,
        "projected_prices": values,
        "projected_change_pct": round(((values[-1] - float(close.iloc[-1])) / float(close.iloc[-1])) * 100, 2),
    }


def next_call_zone(current_price: float, support_levels: list, resistance_levels: list) -> dict:
    """
    Finds the nearest support below and resistance above current price --
    this is the "next call" zone: buy near support, book profit / sell
    near resistance.
    """
    supports_below = sorted([s for s in support_levels if s < current_price], reverse=True)
    resistances_above = sorted([r for r in resistance_levels if r > current_price])

    nearest_support = supports_below[0] if supports_below else min(support_levels, default=current_price * 0.95)
    nearest_resistance = resistances_above[0] if resistances_above else max(resistance_levels, default=current_price * 1.05)

    return {
        "buy_zone_near": round(nearest_support, 2),
        "sell_zone_near": round(nearest_resistance, 2),
        "risk_reward_ratio": round(
            (nearest_resistance - current_price) / max(current_price - nearest_support, 0.01), 2
        ),
    }


def recommendation(analysis: dict, forecast: dict, risk_tolerance: str = "medium") -> dict:
    score = 0
    reasons = []

    if analysis["trend"] == "Uptrend":
        score += 1
        reasons.append("Price is trading above its 20 & 50-day averages (uptrend).")
    elif analysis["trend"] == "Downtrend":
        score -= 1
        reasons.append("Price is trading below its 20 & 50-day averages (downtrend).")
    else:
        reasons.append("Price is moving sideways with no clear trend.")

    rsi = analysis["rsi"]
    if rsi < 30:
        score += 1
        reasons.append(f"RSI is {rsi} — asset looks oversold, often a bounce zone.")
    elif rsi > 70:
        score -= 1
        reasons.append(f"RSI is {rsi} — asset looks overbought, pullback risk.")
    else:
        reasons.append(f"RSI is {rsi} — neutral momentum.")

    macd = analysis["macd"]
    if macd["bullish_cross"]:
        score += 1
        reasons.append("MACD just crossed bullish (upward momentum trigger).")
    elif macd["bearish_cross"]:
        score -= 1
        reasons.append("MACD just crossed bearish (downward momentum trigger).")

    if forecast["projected_change_pct"] > 1:
        score += 1
        reasons.append(f"Short-term model projects a further +{forecast['projected_change_pct']}% move.")
    elif forecast["projected_change_pct"] < -1:
        score -= 1
        reasons.append(f"Short-term model projects a {forecast['projected_change_pct']}% pullback.")

    # risk tolerance shifts the threshold for calling BUY vs HOLD
    thresholds = {"low": 2, "medium": 1, "high": 0}
    buy_threshold = thresholds.get(risk_tolerance, 1)

    if score > buy_threshold:
        call = "BUY"
    elif score < -buy_threshold:
        call = "SELL"
    else:
        call = "HOLD"

    return {"call": call, "score": score, "reasons": reasons}
